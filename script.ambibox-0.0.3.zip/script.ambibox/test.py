print int(1.77777777777777777778*100) & 0xff
print chr((1280 >> 8) & 0xff)
